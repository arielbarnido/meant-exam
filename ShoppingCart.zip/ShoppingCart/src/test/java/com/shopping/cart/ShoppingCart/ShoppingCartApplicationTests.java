package com.shopping.cart.ShoppingCart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingCartApplicationTests {

	@Test
	void contextLoads() {
	}

}
